<img width="1024" height="1536" alt="ChatGPT Image Jan 27, 2026, 09_25_53 PM" src="https://gist.github.com/user-attachments/assets/94bdda3c-c77c-4f83-a566-5ce9ebc7ca08" />
<img width="1500" height="1219" alt="Screenshot 2026-01-22 070847" src="https://gist.github.com/user-attachments/assets/0ca03d69-ac3f-4dc3-ad55-fcf7a36b4981" />
<img width="1132" height="993" alt="Screenshot 2026-01-27 191022" src="https://gist.github.com/user-attachments/assets/f30c4196-3131-438b-9ab4-da5a4e583b2b" />
<img width="250" height="250" alt="Untitled design (3)" src="https://gist.github.com/user-attachments/assets/32341200-d37b-41f2-a0e5-dd4780bd8515" />
<img width="250" height="250" alt="Untitled design (2)" src="https://gist.github.com/user-attachments/assets/05ce97da-21a3-499a-b484-82d83faa8924" />
![Untitled design (3)](https://gist.github.com/user-attachments/assets/b4e68a1c-caf5-4516-ba0b-26ebf76e4363)
![sketch](https://gist.github.com/user-attachments/assets/b8758430-b69f-4f49-84fa-7242071e6a8f)

![Untitled design (2)](https://gist.github.com/user-attachments/assets/929e0bfc-04b1-472b-85ef-ba3563d21f91)


https://gist.github.com/user-attachments/assets/4447e4a5-3b9c-45b7-b317-f8b116c25814

![Untitled design (1)](https://gist.github.com/user-attachments/assets/80685fc7-db0c-475c-9d60-3493d87755e5)

![MDS (1)](https://gist.github.com/user-attachments/assets/0982fad6-1d8f-4e21-9164-8712b9d3e6a8)
![Miquanjiever](https://gist.github.com/user-attachments/assets/c97d60e8-5ebe-4be6-b44b-6cb9939ace3f)
